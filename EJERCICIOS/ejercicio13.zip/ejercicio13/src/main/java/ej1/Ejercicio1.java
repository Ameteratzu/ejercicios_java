package ej1;

import java.util.Scanner;

/**
 *
 * @author Amet
 */
public class Ejercicio1 {
 public static Scanner sc =new Scanner(System.in);
    public static void main(String[] args) {
       int ca;
        double pe,de,up,pro = 0,prom = 0;
        String nom;
        nom=nombre();
        ca=categoria();
        pro=promedio();
        pe=pension(ca);
        de=descuento(pro,ca,pe);
        up=ultimaPension(pe,de);
     
        mostrarResultados(nom,ca,pro,de,up);
     
    }
    public static String nombre(){
       String nom;
        System.out.println("Nombre: ");
        nom = sc.next();
        return nom;
    }
    public static int categoria(){
          int ca;
          System.out.println("categoria:");
          System.out.println("1.-A");
          System.out.println("2.-B");
         System.out.println("3.-C");
        System.out.println("4.-D");
        ca=sc.nextInt();
       
     return ca;
        
    }
    public static double promedio(){
        double pro;
        System.out.println("promedio");
        pro=sc.nextDouble();
     return pro;
        
    }
     public static double pension(int ca){
         double pe = 0;
       if(ca==1){
          pe=550; 
       } else if(ca==2){
           pe=500;
       }else if(ca==3){
           pe=460;
       }else if(ca==4){
           pe=400;
       }else 
             System.out.println("Herror al ingresar datos");
    
     return pe;
        
    }
      public static double descuento(double pro,int ca,double pe ){
          double de = 0;
        if(pro>=0 && pro<=13.99){
           de=pe*0; 
        }else if(pro>=14 && pro<=15.99){
            de=pe*0.1;
        }else if(pro>=16 && pro<=17.99){
            de=pe*0.12;
        }else if(pro>=18 && pro<=20){
            de=pe*0.15;
        }
     return de;    
    }
       public static double ultimaPension(double pe,double de){
        double up;
        up=pe-de;
     return up;
        
    }
       public static void mostrarResultados(String nom,int ca,double pro,double de,double up){
           System.out.println("nombre:      "+nom); 
           System.out.println("Categoria: "+ca);
           System.out.println("promedio: "+pro);
           System.out.println("descuento: "+de);
           System.out.println("pension final: "+up);
          
       }
}
