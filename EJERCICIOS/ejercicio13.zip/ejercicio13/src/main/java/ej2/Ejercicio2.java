/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ej2;

import java.util.Scanner;

/**
 *
 * @author josue
 */
public class Ejercicio2 {
      public static Scanner sc =new Scanner(System.in);
     public static void main(String[] args) {
       String nom,re;
       int procucto;
       int uni,cant,pro;
       double pre;
      nom=nombre();
      pro=producto();
      cant=cantidad();
      pre=precio(pro,cant);
      re=regalos(cant);
     reporte(nom,re);
    }
    public static String nombre(){
       String nom;
        System.out.println("Nombre: ");
        nom = sc.next();
        return nom;
    }
    public static int producto(){
          int pro;
        System.out.println("Producto:");
        System.out.println("1.-P1");
        System.out.println("2.-P2");
        System.out.println("3.-P3");
        pro=sc.nextInt(); 
     return pro;  
    }
     public static int cantidad(){
         int cant = 0;
         System.out.println("Ingrese cantidad a comprar");
         cant=sc.nextInt();
          return cant;
         
     }
     public static double precio(int pro,int cant){
        double pre = 0;
        if(pro==1){
            pre=15*cant;
        }else if(pro==2){
            pre=17.5*cant;
        }else if(pro==3){
            pre=20*cant;
        }else
             System.out.println("Opcion incorrecta");
          return pre;
         
     }
     public static String regalos(int cant){
        String re="";
         if(cant>0 && cant<=25){
           re="un lapicero";
        }else if(cant>=26 && cant<=50){
           re="un cuaderno";
        }else if(cant>50){
           re="una agenda";
        }
          return re;
         
     }
     public static void reporte(String nom,String re){
         System.out.println("nombre:   "+nom);
         System.out.println("regalo adquirido:  "+re);
     }
}
